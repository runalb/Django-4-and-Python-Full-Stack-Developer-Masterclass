from mypackage.mysubmodule import my_sub_func

my_sub_func()