def my_sub_func():
    print("Using a function from mysubmodule.py!")